import 'dart:io';

/// {@template api_constants}
/// Clase de utilidad que centraliza las constantes de la API.
///
/// Contiene la URL base del backend y endpoints específicos.
/// Maneja la diferencia de `localhost` entre Android y otras plataformas.
/// {@endtemplate}
class ApiConstants {
  /// {@template api_constants_base_url}
  /// URL base para todas las llamadas a la API del backend.
  ///
  /// Utiliza `http://10.0.2.2` para el emulador de Android (que es como
  /// el emulador accede al `localhost` de la máquina anfitriona)
  /// y `http://localhost` para otras plataformas (como iOS o web).
  ///
  /// **Nota:** Has cambiado `10.0.2.2` por `192.168.100.5`. Esto es correcto
  /// si estás probando en un dispositivo físico en la misma red Wi-Fi
  /// que tu computadora de desarrollo.
  /// {@endtemplate}
  static String baseUrl =
      Platform.isAndroid ? 'http://192.168.100.5:3000' : 'http://localhost:3000';

  /// Endpoint para el registro de usuarios.
  static String registerEndpoint = '/api/auth/register';

  /// Endpoint para el inicio de sesión de usuarios.
  static String loginEndpoint = '/api/auth/login';
}